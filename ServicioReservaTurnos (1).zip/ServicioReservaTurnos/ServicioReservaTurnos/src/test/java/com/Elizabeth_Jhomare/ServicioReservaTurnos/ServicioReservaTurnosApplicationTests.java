package com.Elizabeth_Jhomare.ServicioReservaTurnos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioReservaTurnosApplicationTests {

	@Test
	void contextLoads() {
	}

}
