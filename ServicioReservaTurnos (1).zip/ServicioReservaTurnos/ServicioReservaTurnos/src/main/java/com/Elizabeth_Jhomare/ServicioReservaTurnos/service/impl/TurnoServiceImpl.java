package com.Elizabeth_Jhomare.ServicioReservaTurnos.service.impl;

import com.Elizabeth_Jhomare.ServicioReservaTurnos.entity.Turno;
import com.Elizabeth_Jhomare.ServicioReservaTurnos.exception.ResourceNotFoundException;
import com.Elizabeth_Jhomare.ServicioReservaTurnos.repository.IOdontologoRepository;
import com.Elizabeth_Jhomare.ServicioReservaTurnos.repository.IPacienteRepository;
import com.Elizabeth_Jhomare.ServicioReservaTurnos.repository.ITurnoRepository;
import com.Elizabeth_Jhomare.ServicioReservaTurnos.service.ITurnoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TurnoServiceImpl implements ITurnoService {

    @Autowired
    private ITurnoRepository iTurnoRepository;

    @Autowired
    private IOdontologoRepository odontologoRepository;

    @Autowired
    private IPacienteRepository pacienteRepository;


    @Override
    public Turno guardar(Turno turno) {
        if (turno == null) {
            throw new IllegalArgumentException("El turno no puede ser null");
        }
        if (turno.getPaciente() == null || turno.getOdontologo() == null) {
            throw new IllegalArgumentException("El paciente o el odontólogo no pueden ser null");
        }
        if (turno.getPaciente().getId() == null) {
            throw new IllegalArgumentException("El paciente debe tener un ID válido");
        }
        if (turno.getOdontologo().getId() == null) {
            throw new IllegalArgumentException("El odontólogo debe tener un ID válido");
        }
        // Verificar la existencia del paciente y odontólogo en la base de datos
        if (!pacienteRepository.existsById(turno.getPaciente().getId())) {
            throw new ResourceNotFoundException("Paciente no encontrado con id: " + turno.getPaciente().getId());
        }
        if (!odontologoRepository.existsById(turno.getOdontologo().getId())) {
            throw new ResourceNotFoundException("Odontólogo no encontrado con id: " + turno.getOdontologo().getId());
        }
        return iTurnoRepository.save(turno);
    }

    @Override
    public Turno buscarPorId(Long id) {
        return iTurnoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("No se encontró el turno con id " + id));
    }

    @Override
    public List<Turno> listarTodos() {
        List<Turno> turnos = iTurnoRepository.findAll();
        if (turnos.isEmpty()) {
            throw new ResourceNotFoundException("No se encontraron turnos registrados");
        }
        return turnos;
    }

    @Override
    public Turno actualizar(Turno turno) {
        if (turno == null || turno.getId() == null) {
            throw new IllegalArgumentException("El turno no puede ser null");
        }
        if (!iTurnoRepository.existsById(turno.getId())) {
            throw new ResourceNotFoundException("No se encontró el turno con id " + turno.getId());
        }
        // Validamos que el odontólogo y paciente existan
        if (turno.getPaciente() == null || turno.getOdontologo() == null) {
            throw new IllegalArgumentException("El paciente o el odontólogo no pueden ser null");
        }
        if (!pacienteRepository.existsById(turno.getPaciente().getId())) {
            throw new ResourceNotFoundException("Paciente no encontrado con id: " + turno.getPaciente().getId());
        }
        if (!odontologoRepository.existsById(turno.getOdontologo().getId())) {
            throw new ResourceNotFoundException("Odontólogo no encontrado con id: " + turno.getOdontologo().getId());
        }
        return iTurnoRepository.save(turno);
    }

    @Override
    public void eliminar(Long id) {
        if (!iTurnoRepository.existsById(id)) {
            throw new ResourceNotFoundException("No se encontró el turno con id " + id);
        }
        iTurnoRepository.deleteById(id);
    }
}
