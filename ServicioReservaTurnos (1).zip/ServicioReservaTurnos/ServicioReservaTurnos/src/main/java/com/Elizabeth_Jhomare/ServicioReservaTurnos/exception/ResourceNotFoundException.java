package com.Elizabeth_Jhomare.ServicioReservaTurnos.exception;

public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
