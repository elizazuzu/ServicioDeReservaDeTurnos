package com.Elizabeth_Jhomare.ServicioReservaTurnos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicioReservaTurnosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicioReservaTurnosApplication.class, args);
	}

}
