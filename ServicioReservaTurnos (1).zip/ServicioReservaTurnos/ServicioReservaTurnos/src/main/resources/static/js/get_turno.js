window.addEventListener('load', function () {

    // Obtener todos los turnos
    (function() {
        const url = '/turnos';
        const settings = {
            method: 'GET'
        };

        fetch(url, settings)
            .then(response => response.json())
            .then(data => {
                console.log(data);  // Esto ayuda a verificar los datos que llegan
                const tableBody = document.getElementById("turnoTableBody");

                data.forEach(turno => {
                    // Crear una fila para cada turno
                    const turnoRow = document.createElement('tr');
                    turnoRow.id = 'tr_' + turno.id;

                    // Formatear fechaHora para hacerla más legible
                    const fechaHoraFormateada = new Date(turno.fechaHora).toLocaleString();

                    // Crear las celdas de la fila
                    turnoRow.innerHTML =
                        '<td class="td_id">' + turno.id + '</td>' +
                        '<td class="td_odontologo">' + (turno.odontologo ? turno.odontologo.nombre + ' ' + turno.odontologo.apellido : 'Desconocido') + '</td>' +
                        '<td class="td_paciente">' + (turno.paciente ? turno.paciente.nombre + ' ' + turno.paciente.apellido : 'Desconocido') + '</td>' +
                        '<td class="td_fechaHora">' + fechaHoraFormateada + '</td>';

                    // Añadir la fila a la tabla
                    tableBody.appendChild(turnoRow);
                });
            })
            .catch(error => console.error('Error:', error));
    })();

});
    // Marcar el enlace de navegación activo
    (function() {
        let pathname = window.location.pathname;
        if (pathname == "/TurnoList.html") {
            document.querySelector(".nav .nav-item a:last").classList.add("active");
        }
    })();
});
